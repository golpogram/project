import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ink: "#14201E",
        "ink-light": "#1F2A28",
        parchment: "#EDE6D6",
        "parchment-light": "#F6F2E8",
        paper: "#F3EEE2",
        brass: "#C9A227",
        "brass-dark": "#A8871E",
        teal: "#4F7C74",
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        sans: ["var(--font-inter)", "sans-serif"],
      },
    },
  },
  plugins: [],
};

export default config;
