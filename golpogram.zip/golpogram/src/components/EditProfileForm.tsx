"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";

type Props = {
  initialName: string;
  initialBio: string;
  initialAvatarUrl: string;
};

export default function EditProfileForm({ initialName, initialBio, initialAvatarUrl }: Props) {
  const router = useRouter();
  const [name, setName] = useState(initialName);
  const [bio, setBio] = useState(initialBio);
  const [avatarUrl, setAvatarUrl] = useState(initialAvatarUrl);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const res = await fetch("/api/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, bio, avatarUrl }),
    });

    const data = await res.json();

    if (!res.ok) {
      setError(data.error ?? "Couldn't save changes. Try again.");
      setLoading(false);
      return;
    }

    router.push("/profile");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <label className="flex flex-col gap-1.5">
        <span className="text-sm font-medium text-ink-light/80">Name</span>
        <input
          type="text"
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="rounded-sm border border-ink/20 bg-parchment-light px-3.5 py-2.5 focus:border-brass outline-none"
        />
      </label>

      <label className="flex flex-col gap-1.5">
        <span className="text-sm font-medium text-ink-light/80">Bio</span>
        <textarea
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          maxLength={500}
          rows={4}
          className="rounded-sm border border-ink/20 bg-parchment-light px-3.5 py-2.5 focus:border-brass outline-none resize-none"
          placeholder="Tell readers a little about yourself and what you write."
        />
      </label>

      <label className="flex flex-col gap-1.5">
        <span className="text-sm font-medium text-ink-light/80">Avatar URL</span>
        <input
          type="text"
          value={avatarUrl}
          onChange={(e) => setAvatarUrl(e.target.value)}
          className="rounded-sm border border-ink/20 bg-parchment-light px-3.5 py-2.5 focus:border-brass outline-none"
          placeholder="https://…"
        />
        <span className="text-xs text-ink-light/50">
          Real image upload comes later — paste a link for now.
        </span>
      </label>

      {error && (
        <p role="alert" className="text-sm text-red-700 bg-red-50 rounded-sm px-3 py-2">
          {error}
        </p>
      )}

      <div className="flex gap-3 mt-2">
        <button
          type="submit"
          disabled={loading}
          className="rounded-sm bg-ink text-paper py-3 px-6 font-medium hover:bg-ink-light transition-colors disabled:opacity-50"
        >
          {loading ? "Saving…" : "Save changes"}
        </button>
      </div>
    </form>
  );
}
