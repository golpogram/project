import Link from "next/link";
import AuthForm from "@/components/AuthForm";

export default function LoginPage() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-14">
      <div className="max-w-sm w-full">
        <Link href="/" className="font-display text-xl">
          Golpogram
        </Link>
        <h1 className="font-display text-3xl mt-6 mb-2">Welcome back</h1>
        <p className="text-ink-light/70 mb-8">Sign in to your Golpogram desk.</p>
        <AuthForm mode="login" />
        <p className="mt-6 text-sm text-ink-light/70">
          New here?{" "}
          <Link href="/signup" className="text-brass-dark underline underline-offset-2">
            Create an account
          </Link>
        </p>
      </div>
    </main>
  );
}
