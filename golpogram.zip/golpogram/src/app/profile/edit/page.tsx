import Link from "next/link";
import { getCurrentUser } from "@/lib/current-user";
import EditProfileForm from "@/components/EditProfileForm";

export default async function EditProfilePage() {
  const user = await getCurrentUser();
  if (!user) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <p className="text-ink-light/70">Session expired. Please sign in again.</p>
      </main>
    );
  }

  return (
    <main className="min-h-screen max-w-lg mx-auto px-6 py-14">
      <Link href="/profile" className="text-sm text-ink-light/60 underline underline-offset-2">
        ← Back to profile
      </Link>
      <h1 className="font-display text-3xl mt-4 mb-8">Edit your profile</h1>
      <EditProfileForm
        initialName={user.name}
        initialBio={user.bio}
        initialAvatarUrl={user.avatarUrl}
      />
    </main>
  );
}
