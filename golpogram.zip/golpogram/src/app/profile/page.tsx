import Link from "next/link";
import { getCurrentUser } from "@/lib/current-user";
import LogoutButton from "@/components/LogoutButton";

export default async function ProfilePage() {
  // Middleware already guarantees a session exists for this route, but we
  // still guard here in case the user record was deleted mid-session.
  const user = await getCurrentUser();
  if (!user) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <p className="text-ink-light/70">Session expired. Please sign in again.</p>
      </main>
    );
  }

  const initial = user.name.trim().charAt(0).toUpperCase() || "?";

  return (
    <main className="min-h-screen">
      <header className="flex items-center justify-between px-6 md:px-16 py-6 border-b border-ink/10">
        <Link href="/" className="font-display text-xl">
          Golpogram
        </Link>
        <LogoutButton />
      </header>

      <section className="max-w-2xl mx-auto px-6 py-14">
        <div className="flex items-center gap-5">
          <div className="w-16 h-16 rounded-full bg-ink text-paper flex items-center justify-center font-display text-2xl shrink-0 overflow-hidden">
            {user.avatarUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={user.avatarUrl} alt="" className="w-full h-full object-cover" />
            ) : (
              initial
            )}
          </div>
          <div>
            <h1 className="font-display text-3xl">{user.name}</h1>
            <p className="text-ink-light/60 text-sm">{user.email}</p>
          </div>
        </div>

        {user.bio ? (
          <p className="mt-6 leading-relaxed text-ink-light/85 max-w-xl">{user.bio}</p>
        ) : (
          <p className="mt-6 text-ink-light/50 italic">No bio yet.</p>
        )}

        <Link
          href="/profile/edit"
          className="mt-6 inline-block text-sm text-brass-dark underline underline-offset-2"
        >
          Edit profile
        </Link>

        <hr className="my-10 border-ink/10" />

        <div className="grid grid-cols-3 gap-6 text-center">
          <StatBlock label="Stories" value={user._count.stories} />
          <StatBlock label="Events" value={user._count.events} />
          <StatBlock label="Posts" value={user._count.posts} />
        </div>

        <p className="mt-10 text-sm text-ink-light/50 leading-relaxed">
          Stories, events, and posts all belong to this same account now — no
          separate logins needed. The editor and library UI for these come
          next.
        </p>
      </section>
    </main>
  );
}

function StatBlock({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="font-display text-3xl">{value}</div>
      <div className="text-sm text-ink-light/50 mt-1">{label}</div>
    </div>
  );
}
