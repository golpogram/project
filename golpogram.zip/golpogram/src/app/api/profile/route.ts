import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/current-user";

const updateSchema = z.object({
  name: z.string().trim().min(2).max(80),
  bio: z.string().trim().max(500).default(""),
  avatarUrl: z.string().trim().max(500).optional().default(""),
});

export async function PATCH(req: NextRequest) {
  const currentUser = await getCurrentUser();
  if (!currentUser) {
    return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) {
    const message = parsed.error.issues[0]?.message ?? "Invalid input";
    return NextResponse.json({ error: message }, { status: 400 });
  }

  const updated = await prisma.user.update({
    where: { id: currentUser.id },
    data: parsed.data,
    select: { id: true, name: true, bio: true, avatarUrl: true },
  });

  return NextResponse.json({ user: updated });
}
