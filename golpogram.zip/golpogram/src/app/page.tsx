import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/current-user";

export default async function HomePage() {
  const user = await getCurrentUser();
  if (user) redirect("/profile");

  return (
    <main className="min-h-screen grid md:grid-cols-2">
      <section className="bg-ink text-paper flex flex-col justify-between px-10 py-14 md:px-16 md:py-20">
        <div className="font-display text-2xl tracking-tight">Golpogram</div>

        <div className="max-w-md">
          <h1 className="font-display text-5xl md:text-6xl leading-[1.05] italic">
            Every story,
            <br />
            one desk.
          </h1>
          <p className="mt-6 text-paper/70 leading-relaxed max-w-sm">
            Write, publish, gather for readings, and message your readers —
            all from the same account. No more juggling logins to be one writer.
          </p>
        </div>

        <p className="text-sm text-paper/40">Golpogram — for storytellers.</p>
      </section>

      <section className="flex items-center justify-center px-10 py-14 md:px-16 md:py-20">
        <div className="max-w-sm w-full">
          <h2 className="font-display text-3xl mb-3">Get started</h2>
          <p className="text-ink-light/70 mb-8 leading-relaxed">
            One account, everything unlocked: your feed, your story library,
            your events, your messages.
          </p>
          <div className="flex flex-col gap-3">
            <Link
              href="/signup"
              className="text-center rounded-sm bg-ink text-paper py-3 font-medium hover:bg-ink-light transition-colors"
            >
              Create an account
            </Link>
            <Link
              href="/login"
              className="text-center rounded-sm border border-ink/20 py-3 font-medium hover:border-ink/40 transition-colors"
            >
              Sign in
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
