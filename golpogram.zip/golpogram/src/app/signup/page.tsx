import Link from "next/link";
import AuthForm from "@/components/AuthForm";

export default function SignupPage() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-14">
      <div className="max-w-sm w-full">
        <Link href="/" className="font-display text-xl">
          Golpogram
        </Link>
        <h1 className="font-display text-3xl mt-6 mb-2">Create your account</h1>
        <p className="text-ink-light/70 mb-8">
          One login for your feed, stories, events, and messages.
        </p>
        <AuthForm mode="signup" />
        <p className="mt-6 text-sm text-ink-light/70">
          Already have an account?{" "}
          <Link href="/login" className="text-brass-dark underline underline-offset-2">
            Sign in
          </Link>
        </p>
      </div>
    </main>
  );
}
