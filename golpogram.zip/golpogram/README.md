# Golpogram — unified auth & profile prototype

This is the foundation piece of the Golpogram rebuild: **one account, one
database**, instead of separate logins for the story library and events.
Everything else (stories, events, feed, messages) will hang off this same
`User` table — the schema already has stub tables for them (see
`prisma/schema.prisma`), they just don't have UI yet.

## Stack

- **Next.js 14** (App Router) — React frontend + API routes in one project
- **Prisma + SQLite** — real relational DB, zero setup locally. Swap to
  Postgres for production by changing one line in `prisma/schema.prisma`.
- **jose** — signs/verifies login sessions (JWT in an httpOnly cookie)
- **bcryptjs** — password hashing
- **Tailwind CSS** — styling
- **zod** — validates every request body server-side

## Running it locally

You'll need [Node.js 18+](https://nodejs.org) installed.

```bash
# 1. Install dependencies
npm install

# 2. Set up your environment file
cp .env.example .env
# Open .env and replace JWT_SECRET with a real random string, e.g. run:
#   openssl rand -base64 32
# and paste the output in.

# 3. Create the database (SQLite file, created automatically)
npm run db:push

# 4. Start the dev server
npm run dev
```

Then open **http://localhost:3000**.

- `/signup` — create an account
- `/login` — sign in
- `/profile` — protected route (middleware redirects to `/login` if not
  signed in); view and edit your unified profile

To inspect the database visually at any point: `npm run db:studio`.

## How auth works (so you can extend it)

1. `/api/auth/signup` and `/api/auth/login` verify the request, hash/compare
   the password with bcrypt, then sign a JWT with `jose` containing the
   user's id and set it as an **httpOnly cookie** (`golpogram_session`).
2. `src/middleware.ts` runs on every request to `/profile/*`, checks that
   cookie is present and valid, and redirects to `/login` if not — this
   check happens at the edge, before any page code runs.
3. `src/lib/current-user.ts` reads that same cookie in server components
   and API routes to fetch the actual logged-in `User` row from Prisma.

This is intentionally framework-light (no NextAuth) so you can see and
modify every part of the auth flow directly. If you later want social login
(Google/Facebook) or magic links, swapping in **Auth.js (NextAuth)** on top
of this same `User` table is a clean next step — the schema won't need to
change.

## What to extend first

Roughly in the order I'd tackle them, since each builds on the last:

1. **Story library + editor** — add `app/stories/page.tsx` (list, scoped to
   `userId`) and `app/stories/new/page.tsx` (create/edit form) using the
   existing `Story` model. This directly kills the "separate account for
   story library" problem, since it's the same login.
2. **Events** — same pattern as stories, using the `Event` model. Add an
   RSVP join table (`EventAttendee`) when you're ready for that.
3. **Feed** — a `Post` list on the homepage for logged-in users, plus a
   `Follow` model (`followerId`, `followingId`) so the feed can be scoped to
   people you follow.
4. **Messages** — a simple inbox UI over the existing `Message` model;
   consider adding real-time updates later with a WebSocket provider
   (Pusher, Ably, or Supabase Realtime) rather than polling.
5. **Search & tags** — once there's real story content, add a `tags` field
   (or a `Tag` model + join table) and a search page. Postgres full-text
   search or a hosted service like Algolia/Typesense both work well here.
6. **Notifications, moderation, reading stats** — these matter more once
   the platform has real users; build them after the core loop (write →
   publish → read → follow) is solid.

## Moving to production

- Switch `datasource db { provider = "sqlite" }` to `"postgresql"` in
  `prisma/schema.prisma`, point `DATABASE_URL` at a hosted Postgres
  (Supabase, Neon, or Railway all have free tiers), run
  `npx prisma migrate dev` once, then deploy.
- Deploy the Next.js app itself to **Vercel** (free tier is generous, and
  it's built by the Next.js team so it "just works").
- Move file/image storage (avatars, story cover images) to **Cloudflare R2**
  or **Supabase Storage** rather than the filesystem.
